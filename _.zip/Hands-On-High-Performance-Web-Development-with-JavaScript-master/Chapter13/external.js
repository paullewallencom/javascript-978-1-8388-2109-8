mergeInto(LibraryManager.library, {
    add: function(x, y) {
        return x + y;
    }
})