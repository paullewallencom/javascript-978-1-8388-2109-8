#include <stdio.h>
extern int add(int, int);

int main() {
    printf("%d\n", add(100, 200));
    return 1;
}