export const trade = {
    symbol : null,
    price : null,
    number : null,
    type : null
};

export const types = {
    SELL : 0,
    BUY : 0
}