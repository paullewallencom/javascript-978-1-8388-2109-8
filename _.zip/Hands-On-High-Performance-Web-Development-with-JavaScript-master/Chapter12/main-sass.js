import main_sass from './template/stylesheets/main.scss'

export default main_sass;