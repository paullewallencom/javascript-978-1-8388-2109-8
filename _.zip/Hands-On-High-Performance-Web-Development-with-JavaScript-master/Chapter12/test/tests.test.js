const esmImport = require('esm')(module);
const cacheTest = esmImport('./cache.tester.js');