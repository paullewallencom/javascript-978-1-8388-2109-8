console.log(process.env.npm_package_config_port);
console.log(process.env.npm_package_config_name);
console.log(process.env.npm_package_config_testdata_thing);
console.log(process.env.npm_package_config_testdata_other);