import os from 'os';

console.log(os.arch());
console.log(os.cpus());