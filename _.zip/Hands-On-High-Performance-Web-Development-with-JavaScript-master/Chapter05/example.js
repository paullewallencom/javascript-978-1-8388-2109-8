const x = 'what';
console.log('this is the value of x', x);
const obj = {
    what : 'that',
    huh : 'this',
    eh : 'yeah'
}
console.log(obj);