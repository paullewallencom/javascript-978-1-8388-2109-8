const os = require('os');

console.log(os.arch());
console.log(os.cpus());