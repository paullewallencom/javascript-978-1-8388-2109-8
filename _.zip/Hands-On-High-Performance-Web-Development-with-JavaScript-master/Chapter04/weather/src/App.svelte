<script>
	import WeatherInput from './WeatherInput.svelte'
	import WeatherOutput from './WeatherOutput.svelte'
</script>
	
<style>
</style>

<WeatherInput></WeatherInput>
<WeatherOutput></WeatherOutput>