export default function() {
    console.log('this is going to be loaded after the initial call');
}